"use strict";

function likes(){
    $.ajax({
        url: "http://localhost:8000/like",
        success:[function (results) {
            console.log(results);
            $("#all-likes").text("");
            for (var i in results){
                var row = document.createElement("tr");
                var users = document.createElement("td");
                var likeTime = document.createElement("td")
                $(users).text(results[i]["username"]);
                $(likeTime).text(results[i]["time"]);
                $(users).appendTo($(row));
                $(likeTime).appendTo($(row));
                $(row).appendTo($("#all-likes"));
                var number=Number(i)+1;
                $("#like-number").text(number);
            }
            document.getElementById("submit-Like").disabled=true;
        }]
    });
}


function comments() {
        $.ajax({
            url: "http://localhost:8000/comment",
            success:[function (results) {
                console.log(results);
                $("#all-comments").text("");
                for (var i in results){
                    var row = document.createElement("tr");
                    var content = document.createElement("td");
                    var user = document.createElement("td");
                    var time = document.createElement("td")
                    $(content).text(results[i]["comment"]);
                    $(user).text(results[i]["username"]);
                    $(time).text(results[i]["time"]);
                    $(content).appendTo($(row));
                    $(user).appendTo($(row));
                    $(time).appendTo($(row));
                    $(row).appendTo($("#all-comments"));
                    var num=Number(i)+1;
                    $("#comment-number").text(num);
                }
            }]
    });
}

function viewLikes(){
    $.ajax({
        url: "http://localhost:8000/viewlikes",
        success:[function (results) {
            console.log(results);
            $("#image-like").text("");
            for (var i in results){
                var singlePics = document.createElement("img");
                var cancelLike = document.createElement("button");
                $(singlePics).attr("src", "asset/uploads/"+results[i]["likeRoute"]);
                $(singlePics).appendTo($("#image-like"));
            }
        }]
    });
}



