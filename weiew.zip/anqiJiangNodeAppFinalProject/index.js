"use strict";

var express = require("express");
var bodyParser = require("body-parser");
var fileUpload = require("express-fileupload");
var session = require("express-session");
var mysql = require("mysql");

var port = 8000;
var app = express();

// Configure static dir
app.use(express.static('asset'));
app.use('/asset',express.static('asset'));

app.use(function(req, res, next) {
    console.log(req.url);
    next();
});

// add cookie into session
app.use(session({secret: "0frYT47nM8wyQxbnTJIBbtEw5PO53269",
    resave: false,
    saveUninitialized: true,
    cookie: {maxAge: 900000}})); //set session data expiration time to 15 minutes

app.set("view_engine", "ejs");
app.set("views", "templates");
app.use(bodyParser.urlencoded({extended: true}));
app.use(fileUpload());
app.use(fileUpload({useTempFiles: true}));

// configure out database connection
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "2007915x",
    database: "Weiew"
});

// show connection info in terminal
con.connect( function(err) {
    if (err) {
        console.log("Error: "+err);
    } else {
        console.log("Successfully connected to DB");
    }
});

// localhost:8000/
app.get("/",function (req,res){
    var sessionData = req.session.data;
    res.render("homepage.ejs",{"data":sessionData});
});

// localhost:8000/paintings
app.get("/paintings",function (req,res){
    var sql = `SELECT*FROM images`;
    con.query(sql,function(err, results) {
        if (err) {
            res.send("Sorry, database error");
        } else {
            console.log(results);
            sql=results;
            res.render("paintings.ejs",{"images":sql});
        }
    });
});

var imageId=0; //set a global value to track the id of current image
// localhost:8000/paintings/:paintingsName
app.get("/paintings/:paintingsId",function (req,res){
    var imgId=req.params.paintingsId;
    imageId=imgId;
    var sql = `SELECT*FROM images WHERE imgId='${imgId}'`; //load pictures
    con.query(sql,function(err, results) {
        if (err) {
            res.send("Sorry, database error");
        } else {
            console.log(results);
            sql=results;
            var likeSql = `SELECT COUNT(imgId) FROM likes WHERE imgId= '${imgId}'` //load like numbers and who liked it
            con.query(likeSql,function(err, results) {
                if (err) {
                    res.send("Sorry, database error");
                } else {
                    console.log(results);
                    likeSql=results;
                    var likeNum=likeSql[0]['COUNT(imgId)'];
                    var commentSql = `SELECT COUNT(imgId) FROM comment WHERE imgId= '${imgId}'` //load comment numbers and who commented
                    con.query(commentSql,function(err, results) {
                        if (err) {
                            res.send("Sorry, database error");
                        } else {
                            console.log(results);
                            commentSql=results;
                            var commentNum = commentSql[0]['COUNT(imgId)'];
                            res.render("singleImage.ejs",{"images":sql,"likeSql":likeNum,"commentSql":commentNum});
                        }
                    });
                }
            });
        }
    });
});


app.post("/paintings/:paintingsId",function(req,res){
    var sessionData = req.session.data;
    var imgId=req.params.paintingsId;
    if (sessionData){
        console.log(imgId);
        var comment = req.body.comment; //read input of comment
        console.log(comment);
        var like = req.body.like; //read input of like
        console.log(like);
        var cancelLike = req.body.cancelLike; //read input of cancel like
        console.log(cancelLike);
        var user = req.session.data;
        console.log(user);
        var sd = require('silly-datetime'); // get current time from the time library
        var time = sd.format(new Date(), 'YYYY-MM-DD HH:mm:ss');
        console.log(time);
        var myDate = new Date();
        var currentTime= myDate.toLocaleString(); // get date and time
        var imgRoute;
        //insert comments into database
        var route = `SELECT*FROM images WHERE imgId = '${imgId}'`
        if (sessionData){
            con.query(route,function(err, results) {
                if (err) {
                    res.send("Sorry, database error");
                } else {
                    console.log(results);
                    route = results;
                    imgRoute = route[0]["imgRoute"];
                    console.log(imgRoute);
                    var sql = `INSERT INTO comment (imgId, comment, username,time,commentRoute) VALUES('${imgId}','${comment}','${user}','${currentTime}','${imgRoute}')`;
                    con.query(sql, function (err, results) {
                        if (err) {
                            res.send("Sorry, database error");
                        } else {
                            console.log(results);
                            sql = results;
                            console.log(sql);
                        }
                    });
                }
            });
        }else {
            res.redirect("/");
        }

        //first check if the user has liked the image before or not, if not, insert the record into "likes"
        var checkUser = `SELECT COUNT(username) FROM likes WHERE username = '${sessionData}' and imgId = '${imgId}'`;
        con.query(checkUser, function(err, results) {
            if (sessionData){
                if (err) {
                    res.send("Error: " + err);
                } else {
                    console.log(results);
                    checkUser = results;
                    var checkName=checkUser[0]['COUNT(username)']; // check if there is a user who has the same username has already liked this picture
                    if(checkName===0){  // means this user hasn't liked the picture before
                        var mySql = `INSERT INTO likes (imgId, likes, username,time,likeRoute) VALUES('${imgId}','${like}','${user}','${currentTime}','${imgRoute}')`;
                        con.query(mySql,function(err, results) {
                            if (err) {
                                res.send("Sorry, database error");
                            } else {
                                console.log(results);
                                mysql=results;
                                console.log(mySql);
                                var deleteInvalidComments = `DELETE FROM comment WHERE comment = "undefined"` //delete invalid comments
                                   con.query(deleteInvalidComments,function (err,results){
                                    if (err){
                                        res.send("database error");
                                    }else{
                                        console.log(results);
                                        deleteInvalidComments=results;
                                        console.log(deleteInvalidComments);
                                    }
                                });
                            }
                        });
                    }else {
                        console.log(results);
                    }
                }
            }else{
                res.redirect("/");
            }
        });
        if(cancelLike){  // if user choose "cancel like", then delete this record from database
            var cancelUserLike=`DELETE FROM likes WHERE username = '${sessionData}'`
            con.query(cancelUserLike, function (err, results) {
                if (err) {
                    res.send("Sorry, database error");
                } else {
                    console.log(results);
                    cancelUserLike = results;
                    console.log(cancelUserLike);
                }
            });
        }
    }else{
        res.redirect("/login");
    }
});

// localhost:8000/comment
// store comment ajax data in /comment
app.get("/comment",function (req,res) {
    console.log(imageId);
    var sql = `SELECT*FROM comment WHERE imgId = '${imageId}'`;
    con.query(sql,function(err, results) {
        if (err) {
            res.send("Sorry, database error");
        } else {
            console.log(results);
            res.json(results);
        }
    });
});

// localhost:8000/like
// store like ajax data in /like
app.get("/like",function (req,res) {
    console.log(imageId);
    var sql = `SELECT*FROM likes WHERE imgId = '${imageId}'`;
    con.query(sql,function(err, results) {
        if (err) {
            res.send("Sorry, database error");
        } else {
            console.log(results);
            res.json(results);
        }
    });
});


// localhost:8000/login
app.get("/login",function (req,res){
    res.render("login.ejs");
});


// If both username and password are correct, go to profile page, otherwise back to homepage
app.post("/login",function (req,res){
    var usernameInput = req.body.username;
    var passwordInput = req.body.password;
    var sql = `SELECT*FROM users`;
    var i;
    var checkName = false; // set a boolean to check if the username input exists in the database
    con.query(sql, function(err, results) {
        if (err) {
            res.send("Error: " + err); // send database loading problems
        } else {
            if (results.length > 0) {
                sql = results;
                console.log(sql);
                // check if the input username match with any existing username
                for (i=0; i < sql.length; i++) {
                    if (usernameInput === sql[i]["username"]) {
                        checkName= true;
                        console.log(i);
                        // if the input matches with an existing username, then check if the password is correct
                        if (passwordInput === sql[i]["password"]) {
                            req.session.data = usernameInput;
                            res.redirect("/profile");
                        } else {
                            res.redirect("/"); // if the password input is incorrect, redirect user to homepage
                        }
                    }
                }
                if (checkName===false){
                    res.redirect("/"); // if the username input is invalid, redirect user to homepage
                }
                checkName = false; // set the boolean to initial value again
            } else {
                res.send("Sorry, database error");
            }
        }
    });
});

// localhost:8000/register
app.get("/register",function (req,res){
    res.render("register.ejs");
});


app.post("/register",function (req,res) {
    var usernameInput = req.body.username;
    var passwordInput = req.body.password;
    var introInput = req.body.intro;
    var userId = 0;
    var checkUser = `SELECT*FROM users`;
    var i;
    var checkName = false; // set a boolean to check if the username input exists in the database
    con.query(checkUser, function(err, results) {
        if (err) {
            res.send("Error: " + err);
        } else {
            checkUser = results;
            console.log(checkUser);
                // check if the input username match with any existing username
            for (i = 0; i < checkUser.length; i++) {
                if (usernameInput === checkUser[i]["username"]) {
                    checkName = true;
                    console.log(checkName);
                }
            }
            if (checkName === true){
                res.redirect("/register"); // if the username already exists, then redirect to register page to change name
            } else {
                var userNum = `SELECT COUNT(userId) FROM users`; // if the username is valid, then store the username and password, then automatically log in
                con.query(userNum, function (err, results) {
                    if (err) {
                        res.send("Sorry, database error");
                    } else {
                        console.log(results);
                        userNum = results[0]["COUNT(userId)"]; // count how many users have alredy been stored in database
                        userId = userNum + 1; // add a new user
                        var sql = `INSERT INTO users (userId, username,password,intro) VALUES('${userId}','${usernameInput}','${passwordInput}','${introInput}')`;
                        con.query(sql, function (err, results) {
                            if (err) {
                                res.send("Sorry, database error");
                            } else {
                                console.log(results);
                                req.session.data = usernameInput;
                                res.redirect("/profile");
                            }
                        });
                    }
                });
            }
        }
    });
});

// localhost:8000/profile
app.get("/profile",function (req,res){
    var sessionData = req.session.data;
    if (sessionData) {
        var sql = `SELECT*FROM users WHERE username='${sessionData}'`;
        con.query(sql,function(err, results) {
            if (err) {
                res.send("Sorry, database error");
            } else {
                console.log(results);
                sql=results;
                var userLike = `SELECT*FROM likes WHERE username='${sessionData}'`;
                con.query(userLike,function(err, results) {
                    if (err) {
                        res.send("Sorry, database error");
                    } else {
                        console.log(results);
                        userLike=results;
                        var userComment = `SELECT*FROM comment WHERE username='${sessionData}'`;
                        con.query(userComment,function(err, results) {
                            if (err) {
                                res.send("Sorry, database error");
                            } else {
                                console.log(results);
                                userComment=results;
                                res.render("profile.ejs", {"userInfo": sql,"userLike":userLike,"userComment":userComment});
                            }
                        });
                    }
                });
            }
        });
    } else {
        res.render("homepage.ejs");
    }
});

// store like ajax data for checking what pictures the user has liked
app.get("/viewlikes",function (req,res){
    var sessionData=req.session.data;
    var sql=`SELECT*FROM likes WHERE username='${sessionData}'`;
    con.query(sql,function(err, results) {
        if (err) {
            res.send("Sorry, database error");
        } else {
            console.log(results);
            sql=results;
            res.json(sql);
        }
    });
})


// delete session data
app.get("/logout", function(req, res) {
    req.session.destroy();
    res.redirect("/");
});

// localhost:8000/upload
app.get("/upload",function (req,res){
    res.render("uploads.ejs");
});


// let user upload file and direct them back to homepage after uploading
app.post("/upload",function (req,res){
    var sessionData = req.session.data;
    if (sessionData){
        var file = req.file.myimage;
        file.mv("asset/uploads/"+file.name);
        var user = req.session.data;
        var imageName= req.body.nameofimage;
        var describe= req.body.imgdescription;
        var route= file.name;
        var sd = require('silly-datetime'); // get current time from the time library
        var time = sd.format(new Date(), 'YYYY-MM-DD HH:mm:ss');
        console.log(time);
        var myDate = new Date();
        var currentTime= myDate.toLocaleString(); // get date and time
        var imgId = 0;
        var sqlId = `SELECT COUNT(imgId) FROM images`;
        con.query(sqlId,function(err, results) {
            if (err) {
                res.send("Sorry, database error");
            } else {
                console.log(results);
                sqlId=results[0]["COUNT(imgId)"]; // count the existing number of artworks, and add a new id to the new picture
                imgId = sqlId+1;
                var sql = `INSERT INTO images (imgId, username, imgName,description,imgRoute,time) VALUES('${imgId}','${user}','${imageName}','${describe}','${route}','${currentTime}')`;
                con.query(sql,function(err, results) {
                    if (err) {
                        res.send("Sorry, database error");
                    } else {
                        console.log(results);
                        sql=results;
                        res.render("uploaded.ejs");
                    }
                });
            }
        });
    }else{
        res.redirect("/");
    }
});


app.listen(port);
console.log("Server running on http://localhost:"+port);