
CREATE TABLE IF NOT EXISTS `images` (
  `imgId` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `imgName` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `imgRoute` varchar(100) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL
);


CREATE TABLE IF NOT EXISTS `users` (
  `userId` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `intro` varchar(250) DEFAULT NULL,
  `avatar` varchar(250) DEFAULT NULL
);


CREATE TABLE IF NOT EXISTS `likes` (
  `imgId` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `likeRoute` varchar(100) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS `comment` (
  `imgId` int(11) NOT NULL,
  `comment` varchar(150) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `commentRoute` varchar(100) DEFAULT NULL
);
